R_RegisterCCallable("RGtk2", "S_GdkFilterFunc", ((DL_FUNC)S_GdkFilterFunc)); 
R_RegisterCCallable("RGtk2", "S_GdkEventFunc", ((DL_FUNC)S_GdkEventFunc)); 
R_RegisterCCallable("RGtk2", "S_GdkPixbufSaveFunc", ((DL_FUNC)S_GdkPixbufSaveFunc)); 
R_RegisterCCallable("RGtk2", "S_GdkSpanFunc", ((DL_FUNC)S_GdkSpanFunc)); 
