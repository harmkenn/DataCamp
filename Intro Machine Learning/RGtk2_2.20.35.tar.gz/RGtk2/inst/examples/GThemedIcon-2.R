c("gnome-dev-cdrom-audio", "gnome-dev-cdrom", "gnome-dev", "gnome")

