## Register an extension point
ep <- gIoExtensionPointRegister("my-extension-point")
ep$setRequiredType(MY_TYPE_EXAMPLE)
